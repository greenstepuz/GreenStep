from flask import Flask, render_template, request, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "your_secret_key")

# Simulatsiya qilish uchun foydalanuvchilarni saqlash
users = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    if 'username' not in session:
        return redirect(url_for('login'))
    username = session['username']
    # Simulatsiya qilish uchun profil ma'lumotlari
    user_data = users.get(username, {})
    return render_template('profile.html', user=user_data)

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        
        # Foydalanuvchini ro'yxatdan o'tkazish
        users[username] = {'email': email, 'password': password, 'points': 0}
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Foydalanuvchi ma'lumotlarini tekshirish
        user = users.get(username)
        if user and check_password_hash(user['password'], password):
            session['username'] = username
            return redirect(url_for('profile'))
        else:
            return "Xato foydalanuvchi nomi yoki parol", 400
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

# Netlify Functions uchun moslashtirilgan handler
def lambda_handler(event, context):
    return app(event, context)